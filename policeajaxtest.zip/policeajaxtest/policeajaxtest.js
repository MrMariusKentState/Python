
var url = "https://api.spotify.com/v1/artists/5NGO30tJxFlKixkPSgXcFE";
var album = "https://api.spotify.com/v1/albums/7yDxJXFPl88Dt9kBo0dDD6";
var clientId = 'bd635ea57fa943b49631ec18eab5ebc8';
var clientSecret = '9422b1f545e143b2bf83c9008497ab7e';
var token = 'BQDHSrM3k4vSmZ0dYfkiQ6beNVjd89mxXqkmqDmIoo_wnIPC-d4N6mb1SAnU5B-PegS8v1JXJncKcC52tiwyZ2_bZ_fNmUEMqLnMYlSp6s7dVmyw5pI_I-bputMHHXjJGhJfDH2LrqONNBuVctc_8w'

//Note that the spotify token above expires after only ONE HOUR.  Find a way to either refresh or use a longer-lasting one.


$(document).ready(function(){

  $.ajax({
    url: url,
    type: 'GET',
    data: {
        grant_type: "authorization_code",
      },
    headers: {
        'Content-Type' : 'application/x-www-form-urlencoded', 
        // 'Authorization' : 'Basic ' + btoa( clientId + ':' + clientSecret)
        'Authorization' : `Bearer ${token}`
    },
    dataType: 'json',
    error: function(){
        console.log('JSON FAILED for data');
    },
    
    
    success:function(results) {
  
      var profile = document.getElementById("police")
      console.log(results);
            
      {
      profile.insertAdjacentHTML('beforeend',"<div>" + results.name + "</div>")
      profile.insertAdjacentHTML('beforeend',"<div>" + results.popularity + "</div>");
      profile.insertAdjacentHTML('beforeend',"<div>" + results.genres + "</div>");
      };
      
      
    //   var cartItemsList = document.getElementById("cartItemsList");

    //   results.basket.productList.forEach(function(element) {
    //   cartItemsList.insertAdjacentHTML( 'beforeend',"<li>" + element.product.name  + "(" + element.product.category + "): " + element.price+ " </li>");

    }  // end of success fn
   }) // end of Ajax call


   $.ajax({
    url: album,
    type: 'GET',
    data: {
        grant_type: "authorization_code",
      },
    headers: {
        'Content-Type' : 'application/x-www-form-urlencoded', 
        // 'Authorization' : 'Basic ' + btoa( clientId + ':' + clientSecret)
        'Authorization' : `Bearer ${token}`
    },
    dataType: 'json',
    error: function(){
        console.log('JSON FAILED for data');
    },
    
    
    success:function(results) {
  
      var album = document.getElementById("synchronicity")
      console.log(results);
      
      {
        album.insertAdjacentHTML('beforeend',"<div>" + results.name + "</div>")
      }

      var i = 0;
      results.tracks.items.forEach(function(element) {
          album.insertAdjacentHTML('beforeend',"<div>" + `{element.i.name}` + "</div>")
          i++
      })

      {album.insertAdjacentHTML('beforeend',"<div>" + results.tracks.items + "</div>")};

    //   var cartItemsList = document.getElementById("cartItemsList");

    //   results.basket.productList.forEach(function(element) {
    //   cartItemsList.insertAdjacentHTML( 'beforeend',"<li>" + element.product.name  + "(" + element.product.category + "): " + element.price+ " </li>");

    }  // end of success fn
   })




 }) // end of $(document).ready() function



