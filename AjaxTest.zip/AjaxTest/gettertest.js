
/* I put your JSON into an external file, loaded from github */
var url = "https://raw.githubusercontent.com/mspanish/playground/master/jessica.json";

/* this tells the page to wait until jQuery has loaded, so you can use the Ajax call */
$(document).ready(function(){
  $.ajax({
    url: url,
    dataType: 'json',
      error: function(){
        console.log('JSON FAILED for data');
      },
    success:function(results){
  /* the results is your json, you can reference the elements directly by using it here, without creating any additional variables */
  
      var cartItemsList = document.getElementById("cartItemsList");

      results.basket.productList.forEach(function(element) {
      cartItemsList.insertAdjacentHTML( 'beforeend',"<li>" +              element.product.name  + "(" + element.product.category + "): " + element.price+ " </li>");
      }); // end of forEach
    }  // end of success fn
   }) // end of Ajax call
 }) // end of $(document).ready() function


//code provided from Stack Overflow:
//https://stackoverflow.com/questions/47850980/display-json-data-to-html-page-using-javascript








async function getAlbums() {

    var response = await fetch(`https://api.spotify.com/v1/albums/7yDxJXFPl88Dt9kBo0dDD6`);
    var albumdata = await response.json();
    return albumdata;
      
  }

  console.log(getAlbums);

    //go back and review APIs and .then functions to complete this!

    
  async function getCoderData() {
      // The await keyword lets js know that it needs to wait until it gets a response back to continue.
      var response = await fetch("https://api.github.com/users/adion81");
      // We then need to convert the data into JSON format.
      var coderData = await response.json();
      return (message="The coder test is a success!");

  }
      
  console.log(getCoderData());