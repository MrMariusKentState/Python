
from flask_app.config.MySQLconnection import MySQLConnection
from flask import flash

class User:
    def __init__( self , data ):
        self.id = data['id']
        self.name = data['name']
        self.location = data['location']
        self.language = data['language']
        self.comment = data['comment']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']

    @classmethod
    def save(cls, data ):
        query = "INSERT INTO dojos ( name, location, language, comment, created_at, updated_at ) VALUES ( %(name)s , %(location)s , %(language)s , %(comment)s, NOW() , NOW() );"
        # data is a dictionary that will be passed into the save method from server.py
        return MySQLConnection('dojo_survey_schema').query_db( query, data )

    @classmethod
    def get_entry(cls):
        query = "SELECT * FROM dojos ORDER BY created_at DESC;"
        results = MySQLConnection('dojo_survey_schema').query_db(query)
        return User(results[0])

    @staticmethod
    def validate(user):
        is_valid = True
        if len(user['name']) < 4:
            flash("Name must be at least 3 characters.")
            is_valid = False
        if len(user['Dojolocation']) < 4:
            flash("You must select a dojo location.")
            is_valid = False
        if len(user['Language']) < 3:
            flash("You must select a language.")
            is_valid = False
        if len(user['comments']) < 3:
            flash("You must provide some comments.")
            is_valid = False
        return is_valid