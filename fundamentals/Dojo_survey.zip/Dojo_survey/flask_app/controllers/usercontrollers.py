
from flask import render_template, request, redirect, session, flash
from flask_app.models.user import User
from flask_app import app



@app.route('/')
def index():
    return render_template("index.html")


@app.route('/info', methods = ['POST'] )
def info():
    data = {
        "name": request.form['name'],
        "location": request.form['Dojolocation'],
        "language": request.form['Language'],
        "comment": request.form['comments']
    }
    if not User.validate(request.form):
        return redirect('/')
    User.save(data)
    return redirect('/result')


@app.route('/result')
def showing():
    user = User.get_entry()
    return render_template("result.html", user = user)


@app.route('/return')
def returning ():
    session.clear()
    return redirect('/')