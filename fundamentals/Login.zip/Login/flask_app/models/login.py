from flask_app.config.MySQLconnect import MySQLConnection
from flask import flash
import re
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$') 


class Login:
    def __init__( self , data ):
        self.id = data['id']
        self.first_name = data['first_name']
        self.last_name = data['last_name']
        self.email = data['email']
        self.password = data['password']
        self.confirm_password = data['confirm_password']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']


    @staticmethod
    def register(user):
        is_valid = True
        if len(user['fname']) < 2:
            flash("Your first name must be at least 2 letters in length.")
            is_valid = False
        if len(user['lname']) < 2:
            flash("Your last name must be at least 2 letters in length.")
            is_valid = False
        if user['fname'].isalpha() == False:
            flash("Your first name must be comprised of letters only.")
            is_valid = False
        if user['lname'].isalpha() == False:
            flash("Your last name must be comprised of letters only.")
            is_valid = False
        if not EMAIL_REGEX.match(user['email']): 
            flash("The email address you have provided is invalid.")
            is_valid = False
        if len(user['password']) < 8:
            flash("Your password must be at least 8 characters in length.")
            is_valid = False
        query = "SELECT * From login_info WHERE email = %(email)s;"
        results = MySQLConnection('login').query_db( query, user )
        if len(results) > 0:
            flash("You must use register with a different email address.");
            is_valid = False;
        query = "SELECT * From login_info WHERE password = %(password)s;"
        results = MySQLConnection('login').query_db( query, user )
        if len(results) > 0:
            flash("This password is not available.  Please choose a different password.");
            is_valid = False;
        if user['password'] != user['cpassword']:
            flash("Your password and password confirmation must match.")
            is_valid = False;
        return is_valid



    @classmethod
    def save(cls, data ):
        query = "INSERT INTO login_info (first_name, last_name, email, password, confirm_password, created_at, updated_at ) VALUES ( %(fname)s, %(lname)s, %(email)s , %(password)s, %(cpassword)s, NOW() , NOW() );"
        return MySQLConnection('login').query_db( query, data )


    # @staticmethod
    # def loginuser(user):
    #     is_valid = True
    #     query = "SELECT * From login_info WHERE email = %(email)s;"
    #     results = MySQLConnection('login').query_db( query, user )
    #     query2 = "SELECT * From login_info WHERE password = %(password)s;"
    #     results2 = MySQLConnection('login').query_db( query2, user )
    #     if len(results) > 0 and len(results2) > 0:
    #         return is_valid
    #     else:
    #         flash("Your email or password does not match. Please try again.")
    #         is_valid = False


    @classmethod
    def get_by_email(cls,data):
        query = "SELECT * FROM login_info WHERE email = %(email)s;"
        result = MySQLConnection('login').query_db(query,data)
        # Didn't find a matching user
        if len(result) < 1:
            return False
        return cls(result[0])


    @classmethod
    def get_user(cls, data):
        query = "SELECT * FROM login_info WHERE id = %(id)s;"
        result = MySQLConnection('login').query_db(query,data)
        return cls(result[0])
    