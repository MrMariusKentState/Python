

from flask import render_template, request, redirect, session, flash
from flask_app.models.login import Login

from flask_app import app
from flask_bcrypt import Bcrypt
bcrypt = Bcrypt(app)


@app.route('/')
def home ():
    return render_template("index.html")


@app.route('/register/user', methods=['POST'])
def register():
    if not Login.register(request.form):
        return redirect('/')
    pw_hash = bcrypt.generate_password_hash(request.form['password'])
    print(pw_hash)
    # put the pw_hash into the data dictionary
    data = {
        "fname": request.form['fname'],
        "lname": request.form['lname'],
        "email": request.form['email'],
        "password" : pw_hash,
        "cpassword": pw_hash
    }
    # Call the save @classmethod on User
    user_id = Login.save(data)
    # store user id into session
    session['user_id'] = user_id
    return render_template("login.html")


@app.route('/next')
def login():
    return render_template("login.html")



@app.route('/login', methods=['POST'])
def login2():
    # see if the username provided exists in the database
    data = { "email" : request.form['loginemail'] }
    user_in_db = Login.get_by_email(data)
    # user is not registered in the db
    if not user_in_db:
        flash("Invalid Email/Password. Please try again.")
        return redirect('/next')
    if not bcrypt.check_password_hash(user_in_db.password, request.form['loginpassword']):
        # if we get False after checking the password
        flash("Invalid Email/Password. Please try again.")
        return redirect('/next')
    # if the passwords matched, we set the user_id into session
    session['user_id'] = user_in_db.id
    # never render on a post!!!
    return redirect('/dashboard')


@app.route('/dashboard')
def dashboard():
    if "user_id" not in session:
        return redirect ('/')
    data = {
        "id": session["user_id"]
    }
    user = Login.get_user(data)
    return render_template("dashboard.html", user = user)


@app.route('/home')
def logout():
    session.clear()
    return redirect ('/')