
from flask import Flask, render_template  # Import Flask to allow us to create our app

check = Flask(__name__)


# @check.route('/')
# def test():
#     return render_template("index.html", num1 = 0, num2 = 4, num3 = 0, num4 = 4)


# @check.route('/<int:num2>')
# def test2(num2):
#     return render_template("index.html", num1 = 0, num2 = 4, num3 = 0, num4 =2)


# @check.route('/<int:num2>/<int:num4>')
# def test3(num2, num4):
#     return render_template ("index.html", num1 = 0, num2 = 10, num3 = 0, num4 = 10)


@check.route('/')
def test():
    return render_template("index.html", x = 8, y = 8)


@check.route('/<int:row_num>')
def test2(row_num):
    return render_template("index.html", x = row_num, y = 8)

@check.route('/<int:row_num>/<int:sq_num>')
def test3(row_num, sq_num):
    return render_template("index.html", x = row_num, y = sq_num)

if __name__=="__main__":   # Ensure this file is being run directly and not from a different module
    check.run(debug=True)