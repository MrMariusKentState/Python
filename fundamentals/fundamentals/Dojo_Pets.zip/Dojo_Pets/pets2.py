from Dojo_Pets import Pet

class Ninja:

    def __init__ (self, first_name, last_name, treats = 50, pet_food = 50, pet = Pet("Freddy","cat","Jumping on a counter")):
        self.first_name = first_name
        self.last_name = last_name
        self.treats = treats
        self.pet_food = pet_food
        self.pet = pet

    def walk (self):
        self.pet.play()
        return self

    def feed (self):
        self.pet.eat()
        return self

    def bathe (self):
        self.pet.noise()
        return self


Freddy = Pet("Rover", "dog", "jumping on the counter")
Freddy.play().noise()
# List = pet_names()