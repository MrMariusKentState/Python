
class Pet:

    def __init__(self, name, type, tricks):
        self.name = name
        self.type = type
        self.tricks = tricks
        self.energy = 100
        self.health = 100

    def sleep(self):
        self.energy += 25
        print(f"The amount of energy {self.name} has is {self.energy}. {self.name}'s health is {self.health}.")
        return self

    def eat(self):
        self.energy += 5
        self.health += 10
        print(f"The amount of energy {self.name} has is {self.energy}. {self.name}'s health is {self.health}.")
        return self

    def play(self):
        self.health += 5
        print(f"The amount of energy {self.name} has is {self.energy}. {self.name}'s health is {self.health}.")
        return self

    def noise(self):
        if self.type == "cat":
            print("Meow!")
        elif self.type == "dog":
            print("Arf! Arf!")
        elif self.type == "bird":
            print("chirp! chirp!")
        else:
            print("Animal noise is unknown.")
        return self


class Ninja:

    def __init__ (self, first_name, last_name, treats = 50, pet_food = 50, pet = Pet("Freddy","cat","Jumping on a counter")):
        self.first_name = first_name
        self.last_name = last_name
        self.treats = treats
        self.pet_food = pet_food
        self.pet = pet

    def walk (self):
        self.pet.play()
        return self

    def feed (self):
        self.pet.eat()
        return self

    def bathe (self):
        self.pet.noise()
        return self


gaiden = Ninja("Ninja", "Gaiden")
Freddy = Pet("Freddy", "dog", "jumping on the counter")

gaiden.feed().walk().bathe()

Freddy.play().sleep().noise()