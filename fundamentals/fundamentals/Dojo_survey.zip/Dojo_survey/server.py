
from flask import Flask, render_template, request, redirect, session

app = Flask(__name__)
# our index route will handle rendering our form
app.secret_key = 'Dojo rules!' # set a secret key for security purposes


@app.route('/')
def index():
    return render_template("index.html")


@app.route('/info', methods = ['POST'] )
def info():
    session['your_name'] = request.form['name']
    session['location'] = request.form['Dojolocation']
    session['language'] = request.form['Language']
    # session['radio'] = request.form['radio']
    # session['checkbox'] = request.form['check']
    session['comments'] = request.form['comments']
    return redirect('/result')


@app.route('/result')
def showing():
    return render_template("result.html")


@app.route('/return')
def returning ():
    session.clear()
    return redirect('/')


if __name__ == "__main__":
    app.run(debug=True)








# @app.route('/')
# def index():
#     return render_template("index.html")


# @app.route('/name', methods = ['POST'] )
# def name():
#     session['your_name'] = request.form['name']


# @app.route('/location', methods = ['POST'])
# def location():
#     session['location'] = request.form['Location']



# @app.route('/language', methods = ['POST'])
# def language():
#     session['language'] = request.form['Language']


# @app.route('/radio', methods = ['POST'])
# def radio ():
#     session['radio'] = request.form['radio']


# @app.route('/checkbox', methods = ['POST'])
# def checkbox ():
#     session['checkbox'] = request.form['check']


# @app.route('/comments', method = ['POST'])
# def comments ():
#     session['comments'] = request.form['comments']


# @app.route('/submit', method = ['POST'])
# def post ():
#     session['post'] = request.form['post']
#     return redirect('/result')