from flask import Flask, render_template, request, redirect, session
from ninja import Ninja
from dojo import Dojo
app = Flask(__name__)    
app.secret_key = 'Dojo rules!'


@app.route('/add_dojo', methods=["POST"])
def add_dojo():
    data = {
        "dojoname": request.form["dojoname"]
    }
    Dojo.save(data)
    return redirect('/dojos')


@app.route('/dojos')
def dojos():
    dojos = Dojo.get_all()
    return render_template("dojos.html", Dojos = dojos)


@app.route('/ninjas')
def ninjas():
    dojos = Dojo.get_all()
    return render_template("ninjas.html", Dojos = dojos)


@app.route('/add_ninja', methods = ['POST'])
def add_ninja():
    data = {
        "dojo_id": request.form["dojo"],
        "fname": request.form["first_name"],
        "lname": request.form["last_name"],
        "age": request.form["age"]
    }
    Ninja.save(data)
    return redirect('/ninjas')


@app.route('/dojos/<int:dojo_id>')
def ninjas2(dojo_id):
    data = {
        "id": dojo_id
    }

    don = Dojo.get_dojo_with_ninjas(data)
    return render_template("ninjalist.html", dojo = don, num = dojo_id)



@app.route('/home')
def home():
    return render_template('/dojos')


@app.route('/')
def default():
    return render_template("ninjalist.html")

@app.route('/home2')
def home2():
    return render_template('/dojos')




if __name__=="__main__":    
    app.run(debug=True) 