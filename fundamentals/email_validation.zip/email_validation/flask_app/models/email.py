from flask_app.config.MySQLConnect import MySQLConnection
import re
from flask import flash
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$') 


class Email:
    def __init__( self , data ):
        self.id = data['id']
        self.email_address = data['email_address']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']

    @classmethod
    def save(cls, data ):
        query = "INSERT INTO email_address (email_address , created_at, updated_at ) VALUES ( %(email)s , NOW() , NOW() );"
        # data is a dictionary that will be passed into the save method from server.py
        return MySQLConnection('emails').query_db( query, data )

    @classmethod
    def get_all(cls):
        query = "SELECT * FROM email_address ORDER BY created_at DESC";
        results = MySQLConnection('emails').query_db(query)
        emails = []
        for address in results:
            emails.append( cls(address) )
        return emails

    # @classmethod
    # def delete(cls, data ):
    #     query = "DELETE FROM email_address WHERE id = %(id)s";
    #     # data is a dictionary that will be passed into the save method from server.py
    #     return MySQLConnection('emails').query_db( query, data )


    @staticmethod
    def validate_user( user ):
        is_valid = True
        if not EMAIL_REGEX.match(user['email']): 
            flash("Invalid email address!")
            is_valid = False
        else:
            flash("The email address you entered is a valid email address!")
        return is_valid

