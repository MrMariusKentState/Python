from flask import render_template, request, redirect, session, flash
from flask_app.models.email import Email
from flask_app import app


@app.route('/')
def home():
    return render_template("index.html")


@app.route('/add_email', methods = ["POST"])
def add_email():
    data = {
        "email": request.form["email"] 
    }
    if not Email.validate_user(request.form):
        return redirect('/')
    Email.save(data)
    return redirect('/success')


# @app.route('/delete', methods = ['POST'])
# def delete():
#     data = {
#         "remove": request.form["delete"]
#     }
#     Email.delete(data)
#     addresses = Email.get_all()
#     return render_template("success.html", Addresses = addresses)


@app.route('/success')
def success():
    addresses = Email.get_all()
    return render_template("success.html", Addresses = addresses)